#!/bin/sh
# Runs the docker image
docker run -it myk8spark bash