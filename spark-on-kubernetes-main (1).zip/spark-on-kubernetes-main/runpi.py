from hellopi import main as hello_main

hello_main()
